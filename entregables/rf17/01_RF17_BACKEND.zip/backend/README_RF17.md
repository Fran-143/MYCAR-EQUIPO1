# Backend RF17 — entrega de implementación

Origen: Fran-143/MYCAR-EQUIPO1, rama feat/mantenimientos-alertas-rf17-rf27,
commit a5d2264f661d138445340d471c59e414da21efe2. Copia de trabajo fuera del repositorio.
No se hicieron commits, push, merge, reset ni cambio de rama en esta entrega.

Se conservan los DAO, servicios, modelos, bloqueo de vehículo, transacciones y pruebas existentes.
Se completan límites de textos/importes y guardas de entrada. Se añaden consultas de contexto y
lecturas RF17 y la capa HTTP propuesta, con DTO, validación y errores.
No se alteran V1–V4, esquema mycar, datos reales, dependencias ni servicios de otras integrantes.

El núcleo RegistroMantenimientoService sigue siendo una entrada INTERNA: exige identidad resuelta
por el backend. Conserva vehículo propio ACTIVO, tipo ACTIVO, reglas LECTURA/HISTORICO_MANUAL,
repuestos finales, costo null/0, recomendaciones y rollback. RF17 no crea lecturas ni alertas.
La nueva API se protege además con los adaptadores descritos en CONTRATO_RF17_PROPUESTO.md.

IMPORTANTE: no existe confirmación compartida de HTTP/idempotencia ni código de sesión de Elsa.
El controlador está deshabilitado por defecto. El guardado HTTP está bloqueado sin el adaptador
común confirmado; no hay fallback que ignore idOperacion o use un usuario arbitrario.
El núcleo interno no adquiere idempotencia solamente por recibir ese UUID.

Validación cronológica: se conserva la implementación actual, incluidos límites de días anteriores
/posteriores y sus igualdades. Siguen pendientes las decisiones aprobadas de mismo día, igualdad y
coherencia de una lectura futura RF14 frente a un mantenimiento manual ya guardado. No se inventa
hora del servicio ni una regla RF14; se debe coordinar ese punto con Francesca.

## Compilación y entorno local

El ZIP contiene backend completo con pom.xml, wrappers, código, recursos y pruebas originales.
Desde backend, en Windows: `.\mvnw.cmd -DskipTests test-compile`.
Para empaquetar cuando Maven pueda descargar los plugins: `.\mvnw.cmd -DskipTests package`.
Para arrancar hacen falta las variables/archivo local PostgreSQL que ya usa el equipo.
No se entrega .env ni credenciales. La importación ../.env de application.properties se conserva;
MYCAR_ENV_FILE permite apuntar al archivo local aprobado. No iniciar apuntando a una BD ajena.
No se modifica la configuración compartida de seguridad, datasource, Flyway ni sus flags.
La API solo debe habilitarse con mycar.rf17.api-habilitada=true tras acordar el contrato e identidad.

Se compilaron fuentes y las pruebas existentes sin ejecutarlas; no se ejecutó una suite JUnit/JDBC.
El entorno de compilación disponible usa JDK 25 con release 21 del pom; no es una prueba runtime Java 21.
No se arrancó este servidor contra la BD real, no se verificó HTTP extremo a extremo y no se entregó JAR.
El intento de package offline encontró plugins no almacenados en caché; test-compile sí es la comprobación
relevante de código solicitada. Ver resumen y logs finales de esta entrega.

Descomprimir en una carpeta aparte y comparar con la rama de origen antes de integrar. No sobrescribir
cambios locales posteriores al commit indicado. El ZIP API es una vista de revisión, no otro servidor.
