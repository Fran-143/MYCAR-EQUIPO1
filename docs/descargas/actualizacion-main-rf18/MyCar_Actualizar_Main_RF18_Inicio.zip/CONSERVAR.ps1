﻿[CmdletBinding()]
param([string]$Repositorio="C:\Proyectos\MyCarEquipo1")
$ErrorActionPreference='Stop'
$mMyCar=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFIESTO_SESION_ORIGINAL.json') -Raw | ConvertFrom-Json
$ramaMyCar=(& git -C $Repositorio branch --show-current).Trim()
if ($LASTEXITCODE -ne 0 -or $ramaMyCar -ne $mMyCar.rama) { throw "Se necesita la rama $($mMyCar.rama)." }
if ((& git -C $Repositorio rev-parse HEAD).Trim() -ne $mMyCar.baseCommit) { throw 'El commit base cambió; comparte git status y git log -1 antes de continuar.' }
foreach ($fMyCar in $mMyCar.archivos) {
    $pMyCar=Join-Path $Repositorio $fMyCar.ruta
    if (!(Test-Path -LiteralPath $pMyCar -PathType Leaf)) { throw "Falta $($fMyCar.ruta). No se agregó nada." }
    $contenidoMyCar=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($pMyCar)).Replace("`r`n","`n")
    $shaMyCar=[Security.Cryptography.SHA256]::Create()
    try { $hashMyCar=([BitConverter]::ToString($shaMyCar.ComputeHash([Text.Encoding]::UTF8.GetBytes($contenidoMyCar)))).Replace('-','').ToLowerInvariant() }
    finally { $shaMyCar.Dispose() }
    if ($hashMyCar -ne $fMyCar.sha256) { throw "Hay cambios adicionales en $($fMyCar.ruta). No se agregó nada; revisémoslos antes de continuar." }
}
$rutasMyCar=@($mMyCar.archivos | ForEach-Object { $_.ruta })
$agregadosMyCar=@(& git -C $Repositorio diff --cached --name-only)
foreach ($rutaMyCar in $agregadosMyCar) {
    if ($rutaMyCar -and $rutaMyCar -notin $rutasMyCar) { throw "Ya hay otro archivo preparado: $rutaMyCar. Revisarlo antes de continuar." }
}
& git -C $Repositorio add -- $rutasMyCar
if ($LASTEXITCODE -ne 0) { throw 'No se pudieron preparar los archivos.' }
& git -C $Repositorio diff --cached --check
if ($LASTEXITCODE -ne 0) { throw 'Revisar diff --cached --check.' }
& git --no-pager -C $Repositorio diff --cached --stat
Write-Host 'Los 30 archivos de sesión están preparados. Revisa la lista y ejecuta el commit local indicado en la guía.'
Write-Host 'No se hizo commit, push, merge ni cambios de BD.'
