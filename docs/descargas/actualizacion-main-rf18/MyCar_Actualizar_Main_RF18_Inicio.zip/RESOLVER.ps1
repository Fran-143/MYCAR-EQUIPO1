﻿[CmdletBinding()]
param([string]$Repositorio="C:\Proyectos\MyCarEquipo1")
$ErrorActionPreference='Stop'
$mMyCar=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFIESTO_RESOLUCION.json') -Raw | ConvertFrom-Json
$ramaMyCar=(& git -C $Repositorio branch --show-current).Trim()
if ($LASTEXITCODE -ne 0 -or $ramaMyCar -ne 'feat/integracion-sesion-vehiculos') { throw 'Se necesita feat/integracion-sesion-vehiculos.' }
$entradaMyCar=& git -C $Repositorio rev-parse -q --verify MERGE_HEAD
if ($LASTEXITCODE -ne 0 -or $entradaMyCar.Trim() -ne $mMyCar.mainRevisado) { throw 'No está pendiente el merge revisado de main. Comparte git status; no se reemplazó nada.' }
$permitidosMyCar=@('android/app/src/main/java/com/mycar/app/MainActivity.kt','android/app/src/main/java/com/mycar/app/features/inicio/HomeScreen.kt')
$conflictosMyCar=@(& git -C $Repositorio diff --name-only --diff-filter=U)
foreach ($rutaMyCar in $conflictosMyCar) {
    if ($rutaMyCar -and $rutaMyCar -notin $permitidosMyCar) { throw "Hay otro conflicto: $rutaMyCar. No se reemplazó nada; revisémoslo." }
}
$raizMyCar=[IO.Path]::GetFullPath($Repositorio).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
foreach ($fMyCar in $mMyCar.archivos) {
    $origenMyCar=Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta
    $destinoMyCar=[IO.Path]::GetFullPath((Join-Path $Repositorio $fMyCar.ruta))
    if (!$destinoMyCar.StartsWith($raizMyCar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Ruta fuera del repositorio.' }
    if (!(Test-Path -LiteralPath $origenMyCar -PathType Leaf) -or (Get-FileHash -LiteralPath $origenMyCar -Algorithm SHA256).Hash.ToLowerInvariant() -ne $fMyCar.sha256) { throw "Paquete incompleto o modificado: $($fMyCar.ruta)" }
}
$respaldoMyCar=Join-Path $env:USERPROFILE ('RespaldosMyCar\antes-resolver-inicio-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
foreach ($fMyCar in $mMyCar.archivos) {
    $origenMyCar=Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta
    $destinoMyCar=Join-Path $Repositorio $fMyCar.ruta
    if (Test-Path -LiteralPath $destinoMyCar) {
        $copiaMyCar=Join-Path $respaldoMyCar $fMyCar.ruta
        New-Item -ItemType Directory -Path (Split-Path -Parent $copiaMyCar) -Force | Out-Null
        Copy-Item -LiteralPath $destinoMyCar -Destination $copiaMyCar
    }
    New-Item -ItemType Directory -Path (Split-Path -Parent $destinoMyCar) -Force | Out-Null
    Copy-Item -LiteralPath $origenMyCar -Destination $destinoMyCar -Force
}
$rutasMyCar=@($mMyCar.archivos | ForEach-Object { $_.ruta })
& git -C $Repositorio add -- $rutasMyCar
if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar la resolución.' }
$pendientesMyCar=@(& git -C $Repositorio diff --name-only --diff-filter=U)
if ($pendientesMyCar) { throw 'Todavía hay conflictos; comparte git status.' }
& git -C $Repositorio diff --cached --check
if ($LASTEXITCODE -ne 0) { throw 'Revisar diff --cached --check antes de continuar.' }
Write-Host "Resolución aplicada. Respaldo: $respaldoMyCar"
Write-Host 'Ejecuta las pruebas antes del commit final. No se hizo commit, push ni cambios de BD.'
& git -C $Repositorio status --short --branch
