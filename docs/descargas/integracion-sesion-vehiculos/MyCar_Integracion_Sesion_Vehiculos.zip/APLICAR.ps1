﻿[CmdletBinding()]
param([string]$Repositorio = "C:\Proyectos\MyCarEquipo1")
$ErrorActionPreference = "Stop"
$manifiestoMyCar = Get-Content -LiteralPath (Join-Path $PSScriptRoot "MANIFIESTO.json") -Raw | ConvertFrom-Json
$ramaMyCar = (& git -C $Repositorio branch --show-current).Trim()
if ($LASTEXITCODE -ne 0 -or $ramaMyCar -ne $manifiestoMyCar.rama) {
    throw "Debes estar en $($manifiestoMyCar.rama). Este auxiliar no cambia ramas."
}
$headMyCar = (& git -C $Repositorio rev-parse HEAD).Trim()
if ($headMyCar -ne $manifiestoMyCar.baseCommit) { throw "La base cambió. Comparte git log -1 --oneline; no se reemplazó ningún archivo." }
$estadoMyCar = & git -C $Repositorio status --porcelain
if ($estadoMyCar) { throw "Hay cambios locales. Consérvalos antes de aplicar; este auxiliar no usa reset ni clean." }
$raizCompletaMyCar = [System.IO.Path]::GetFullPath($Repositorio).TrimEnd('\','/') + [System.IO.Path]::DirectorySeparatorChar
# Verifica TODO antes de escribir. Solo se aceptan las rutas del manifiesto y sus hashes.
foreach ($itemMyCar in $manifiestoMyCar.archivos) {
    $origenMyCar = Join-Path (Join-Path $PSScriptRoot "ARCHIVOS") $itemMyCar.ruta
    $destinoMyCar = [System.IO.Path]::GetFullPath((Join-Path $Repositorio $itemMyCar.ruta))
    if (!$destinoMyCar.StartsWith($raizCompletaMyCar,[StringComparison]::OrdinalIgnoreCase)) { throw "Ruta fuera del repositorio." }
    if (!(Test-Path -LiteralPath $origenMyCar -PathType Leaf) -or
        (Get-FileHash -LiteralPath $origenMyCar -Algorithm SHA256).Hash.ToLowerInvariant() -ne $itemMyCar.sha256) {
        throw "Paquete incompleto o modificado: $($itemMyCar.ruta)"
    }
    if ($itemMyCar.sha256Base) {
        if (!(Test-Path -LiteralPath $destinoMyCar -PathType Leaf) -or
            (Get-FileHash -LiteralPath $destinoMyCar -Algorithm SHA256).Hash.ToLowerInvariant() -ne $itemMyCar.sha256Base) {
            # Git puede haber convertido LF a CRLF sin cambiar el contenido lógico.
            if (!(Test-Path -LiteralPath $destinoMyCar -PathType Leaf)) { throw "Falta archivo base: $($itemMyCar.ruta)" }
            $textoMyCar = [IO.File]::ReadAllText($destinoMyCar).Replace("`r`n","`n")
            $shaMyCar = [Security.Cryptography.SHA256]::Create()
            try { $hashMyCar = ([BitConverter]::ToString($shaMyCar.ComputeHash([Text.Encoding]::UTF8.GetBytes($textoMyCar)))).Replace('-','').ToLowerInvariant() }
            finally { $shaMyCar.Dispose() }
            if ($hashMyCar -ne $itemMyCar.sha256Base) { throw "Contenido base distinto: $($itemMyCar.ruta)" }
        }
    } elseif (Test-Path -LiteralPath $destinoMyCar) { throw "Ya existe un archivo nuevo del paquete: $($itemMyCar.ruta)" }
}
$carpetaRespaldoMyCar = Join-Path $env:USERPROFILE ("RespaldosMyCar\antes-integrar-sesion-" + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $carpetaRespaldoMyCar -Force | Out-Null
foreach ($itemMyCar in $manifiestoMyCar.archivos) {
    $origenMyCar = Join-Path (Join-Path $PSScriptRoot "ARCHIVOS") $itemMyCar.ruta
    $destinoMyCar = Join-Path $Repositorio $itemMyCar.ruta
    if (Test-Path -LiteralPath $destinoMyCar) {
        $respaldoMyCar = Join-Path $carpetaRespaldoMyCar $itemMyCar.ruta
        New-Item -ItemType Directory -Path (Split-Path -Parent $respaldoMyCar) -Force | Out-Null
        Copy-Item -LiteralPath $destinoMyCar -Destination $respaldoMyCar
    }
    New-Item -ItemType Directory -Path (Split-Path -Parent $destinoMyCar) -Force | Out-Null
    Copy-Item -LiteralPath $origenMyCar -Destination $destinoMyCar -Force
}
Write-Host "Archivos aplicados en tu rama. Respaldo: $carpetaRespaldoMyCar"
Write-Host "Sin cambios de BD, commit, push ni merge. Ahora ejecuta las pruebas de LEEME_PRIMERO.md."
& git -C $Repositorio diff --check
if ($LASTEXITCODE -ne 0) { throw "Revisar diff --check antes de continuar." }
& git -C $Repositorio status --short --branch
