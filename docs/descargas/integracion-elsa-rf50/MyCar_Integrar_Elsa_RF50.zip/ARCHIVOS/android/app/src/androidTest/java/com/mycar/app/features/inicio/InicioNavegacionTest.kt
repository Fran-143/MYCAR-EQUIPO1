package com.mycar.app.features.inicio

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.espresso.Espresso
import com.mycar.app.MainActivity
import org.junit.Rule
import org.junit.Test

/** Ejecutar sin sesión activa en el emulador de pruebas; no crea cuentas ni registros. */
class InicioNavegacionTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    private fun bienvenida() {
        compose.waitUntil(10_000) {
            compose.onAllNodesWithText("Crear cuenta").fetchSemanticsNodes().isNotEmpty()
        }
    }
    @Test fun entradaUsaBienvenidaRealSinDatosDeEjemplo() {
        bienvenida()
        compose.onNodeWithText("Iniciar sesión").assertExists()
        compose.onNodeWithText("Hola, Carlos").assertDoesNotExist()
        compose.onNodeWithText("58 240 km").assertDoesNotExist()
        compose.onNodeWithText("Comprobar conexión").assertDoesNotExist()
    }
    @Test fun loginDeElsaRegresaABienvenida() {
        bienvenida()
        compose.onNodeWithText("Iniciar sesión").performClick()
        compose.onNodeWithText("Correo electrónico").assertExists()
        compose.onNodeWithText("Contraseña").assertExists()
        Espresso.pressBack()
        compose.onNodeWithText("Crear cuenta").assertExists()
    }
    @Test fun registroDeCuentaUsaLaPantallaReal() {
        bienvenida()
        compose.onNodeWithText("Crear cuenta").performClick()
        compose.onNodeWithText("Nombre").assertExists()
        compose.onNodeWithText("Fecha de nacimiento").assertExists()
        compose.onNodeWithText("Modo de prueba · no guarda vehículos en la BD").assertDoesNotExist()
        Espresso.pressBack()
        compose.onNodeWithText("Iniciar sesión").assertExists()
    }
}
