﻿[CmdletBinding()]
param([string]$Repositorio='C:\Proyectos\MyCarEquipo1')
$ErrorActionPreference='Stop'
$mMyCar=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFIESTO.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if((& git -C $Repositorio branch --show-current).Trim() -ne $mMyCar.rama) { throw 'Usa feat/integracion-sesion-vehiculos. No se reemplazó ningún archivo.' }
$mergeMyCar=& git -C $Repositorio rev-parse -q --verify MERGE_HEAD
if($LASTEXITCODE -ne 0 -or $mergeMyCar.Trim() -ne $mMyCar.mainEntrante) { throw 'Este paquete requiere el merge pendiente de main 529927a. Comparte git status y git log -1 --oneline; no se reemplazó nada.' }
$conflictosMyCar=@(& git -C $Repositorio diff --name-only --diff-filter=U)
if($conflictosMyCar.Count -ne @($mMyCar.conflictos).Count) { throw 'Los conflictos ya se resolvieron o son distintos. Comparte git status; no se reemplazó nada.' }
$diferenciasMyCar=@(Compare-Object -ReferenceObject @($mMyCar.conflictos) -DifferenceObject $conflictosMyCar)
if($diferenciasMyCar.Count -ne 0) { throw 'Los conflictos no coinciden con los dos revisados. Comparte git status; no se reemplazó nada.' }
$sinGuardarMyCar=@(& git -C $Repositorio diff --name-only)
foreach($rutaMyCar in $sinGuardarMyCar) {
    if($rutaMyCar -notin $mMyCar.conflictos) { throw "Hay cambios posteriores al merge en $rutaMyCar. No se reemplazó nada." }
}
$nuevosMyCar=@(& git -C $Repositorio ls-files --others --exclude-standard)
if($nuevosMyCar.Count -gt 0) { throw 'Hay archivos nuevos sin conservar. Comparte git status antes de aplicar; no se reemplazó nada.' }
function LeerObjetoGitMyCar([string]$objetoMyCar) {
    $procesoMyCar=New-Object System.Diagnostics.Process
    $procesoMyCar.StartInfo.FileName='git'
    $procesoMyCar.StartInfo.WorkingDirectory=$Repositorio
    $procesoMyCar.StartInfo.Arguments='cat-file blob "'+$objetoMyCar+'"'
    $procesoMyCar.StartInfo.UseShellExecute=$false
    $procesoMyCar.StartInfo.RedirectStandardOutput=$true
    $procesoMyCar.StartInfo.RedirectStandardError=$true
    $memoriaMyCar=New-Object System.IO.MemoryStream
    try {
        [void]$procesoMyCar.Start()
        $procesoMyCar.StandardOutput.BaseStream.CopyTo($memoriaMyCar)
        $errorGitMyCar=$procesoMyCar.StandardError.ReadToEnd()
        $procesoMyCar.WaitForExit()
        if($procesoMyCar.ExitCode -ne 0) { throw "No se pudo leer la base Git de $objetoMyCar" }
        return ,$memoriaMyCar.ToArray()
    } finally { $memoriaMyCar.Dispose(); $procesoMyCar.Dispose() }
}
function HashNormalizadoMyCar([byte[]]$bytesMyCar) {
    $textoMyCar=[Text.Encoding]::UTF8.GetString($bytesMyCar).Replace("`r`n","`n")
    $shaMyCar=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($shaMyCar.ComputeHash([Text.Encoding]::UTF8.GetBytes($textoMyCar)))).Replace('-','').ToLowerInvariant() }
    finally { $shaMyCar.Dispose() }
}
foreach($baseMyCar in $mMyCar.prerequisitos) {
    $rutaBaseMyCar=Join-Path $Repositorio $baseMyCar.ruta
    if(!(Test-Path -LiteralPath $rutaBaseMyCar -PathType Leaf) -or (HashNormalizadoMyCar ([IO.File]::ReadAllBytes($rutaBaseMyCar))) -ne $baseMyCar.sha256) {
        throw "La base de integración cambió en $($baseMyCar.ruta). No se reemplazó nada."
    }
}
$raizMyCar=[IO.Path]::GetFullPath($Repositorio).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
foreach($fMyCar in $mMyCar.archivos) {
    $destinoMyCar=[IO.Path]::GetFullPath((Join-Path $Repositorio $fMyCar.ruta))
    if(!$destinoMyCar.StartsWith($raizMyCar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Ruta fuera del repositorio.' }
    $origenMyCar=Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta
    if(!(Test-Path -LiteralPath $origenMyCar -PathType Leaf) -or (Get-FileHash -LiteralPath $origenMyCar -Algorithm SHA256).Hash.ToLowerInvariant() -ne $fMyCar.sha256) { throw "Paquete incompleto o alterado: $($fMyCar.ruta)" }
    if($fMyCar.sha256Base) {
        if((HashNormalizadoMyCar (LeerObjetoGitMyCar $fMyCar.referenciaBase)) -ne $fMyCar.sha256Base) { throw "La base cambió en $($fMyCar.ruta). No se reemplazó nada." }
    } elseif(Test-Path -LiteralPath $destinoMyCar) { throw "Ya existe $($fMyCar.ruta). No se reemplazó nada." }
}
$respaldoMyCar=Join-Path $env:USERPROFILE ('RespaldosMyCar/antes-integrar-elsa-rf50-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
foreach($fMyCar in $mMyCar.archivos) {
    $destinoMyCar=Join-Path $Repositorio $fMyCar.ruta
    if(Test-Path -LiteralPath $destinoMyCar) {
        $copiaMyCar=Join-Path $respaldoMyCar $fMyCar.ruta
        New-Item -ItemType Directory -Path (Split-Path -Parent $copiaMyCar) -Force | Out-Null
        Copy-Item -LiteralPath $destinoMyCar -Destination $copiaMyCar
    }
}
foreach($fMyCar in $mMyCar.archivos) {
    $destinoMyCar=Join-Path $Repositorio $fMyCar.ruta
    New-Item -ItemType Directory -Path (Split-Path -Parent $destinoMyCar) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta) -Destination $destinoMyCar -Force
}
$rutasMyCar=@($mMyCar.archivos | ForEach-Object { $_.ruta })
& git -C $Repositorio add -- $rutasMyCar
if($LASTEXITCODE -ne 0) { throw 'No se pudieron preparar todos los archivos. Comparte git status.' }
& git -C $Repositorio diff --cached --check
if($LASTEXITCODE -ne 0) { throw 'Revisar los detalles de formato antes del commit.' }
if(@(& git -C $Repositorio diff --name-only --diff-filter=U).Count -ne 0) { throw 'Queda un conflicto pendiente. Comparte git status.' }
Write-Host "Integración aplicada y conflictos preparados. Respaldo: $respaldoMyCar"
Write-Host 'El merge sigue pendiente de tu revisión y commit. Sin push, merge en GitHub ni cambios de BD.'
Write-Host 'Ejecuta las pruebas de LEEME_PRIMERO.md.'
& git -C $Repositorio status --short --branch
