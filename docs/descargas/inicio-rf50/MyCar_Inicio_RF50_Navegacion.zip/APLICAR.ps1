﻿[CmdletBinding()]
param([string]$Repositorio='C:\Proyectos\MyCarEquipo1')
$ErrorActionPreference='Stop'
$mMyCar=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFIESTO.json') -Raw | ConvertFrom-Json
$ramaMyCar=(& git -C $Repositorio branch --show-current).Trim()
if($LASTEXITCODE -ne 0 -or $ramaMyCar -ne 'feat/integracion-sesion-vehiculos') { throw 'Usa feat/integracion-sesion-vehiculos; no se instalará sobre main.' }
$mergeMyCar=& git -C $Repositorio rev-parse -q --verify MERGE_HEAD
if($LASTEXITCODE -eq 0) { throw 'Tu merge local sigue pendiente. Si todos los conflictos están resueltos, termina primero con el commit local indicado en la guía. No se reemplazó nada.' }
$estadoMyCar=& git -C $Repositorio status --porcelain
if($estadoMyCar) { throw 'Hay cambios locales sin conservar. Comparte git status antes de aplicar; no se reemplazó nada.' }
& git -C $Repositorio merge-base --is-ancestor $mMyCar.mainRevisado HEAD
if($LASTEXITCODE -ne 0) { throw 'Falta incorporar el main RF18 revisado. No se reemplazó nada.' }
function HashNormalizadoMyCar([string]$rutaMyCar) {
    $textoMyCar=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($rutaMyCar)).Replace("`r`n","`n")
    $shaMyCar=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($shaMyCar.ComputeHash([Text.Encoding]::UTF8.GetBytes($textoMyCar)))).Replace('-','').ToLowerInvariant() }
    finally { $shaMyCar.Dispose() }
}
$raizMyCar=[IO.Path]::GetFullPath($Repositorio).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
foreach($fMyCar in $mMyCar.archivos) {
    $origenMyCar=Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta
    $destinoMyCar=[IO.Path]::GetFullPath((Join-Path $Repositorio $fMyCar.ruta))
    if(!$destinoMyCar.StartsWith($raizMyCar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Ruta fuera del repositorio.' }
    if(!(Test-Path -LiteralPath $origenMyCar -PathType Leaf) -or (Get-FileHash -LiteralPath $origenMyCar -Algorithm SHA256).Hash.ToLowerInvariant() -ne $fMyCar.sha256) { throw "Paquete incompleto o alterado: $($fMyCar.ruta)" }
    if($fMyCar.sha256Base) {
        if(!(Test-Path -LiteralPath $destinoMyCar -PathType Leaf) -or (HashNormalizadoMyCar $destinoMyCar) -ne $fMyCar.sha256Base) { throw "Base distinta en $($fMyCar.ruta). Comparte la salida antes de continuar; no se reemplazó nada." }
    } elseif(Test-Path -LiteralPath $destinoMyCar) { throw "Ya existe un archivo nuevo del paquete: $($fMyCar.ruta). Revisarlo antes de continuar." }
}
$respaldoMyCar=Join-Path $env:USERPROFILE ('RespaldosMyCar\antes-inicio-rf50-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
foreach($fMyCar in $mMyCar.archivos) {
    $origenMyCar=Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta
    $destinoMyCar=Join-Path $Repositorio $fMyCar.ruta
    if(Test-Path -LiteralPath $destinoMyCar) {
        $copiaMyCar=Join-Path $respaldoMyCar $fMyCar.ruta
        New-Item -ItemType Directory -Path (Split-Path -Parent $copiaMyCar) -Force | Out-Null
        Copy-Item -LiteralPath $destinoMyCar -Destination $copiaMyCar
    }
    New-Item -ItemType Directory -Path (Split-Path -Parent $destinoMyCar) -Force | Out-Null
    Copy-Item -LiteralPath $origenMyCar -Destination $destinoMyCar -Force
}
Write-Host "Inicio RF50 aplicado en tu rama. Respaldo: $respaldoMyCar"
Write-Host 'Sin cambios de BD, commit, push ni merge. Ejecuta las pruebas antes de subir.'
& git -C $Repositorio diff --check
if($LASTEXITCODE -ne 0) { throw 'Revisar diff --check.' }
& git -C $Repositorio status --short --branch
