﻿[CmdletBinding()]
param([string]$Repositorio='C:\Proyectos\MyCarEquipo1')
$ErrorActionPreference='Stop'
$mMyCar=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFIESTO.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if((& git -C $Repositorio branch --show-current).Trim() -ne $mMyCar.rama) { throw 'Usa feat/integracion-sesion-vehiculos. No se reemplazó nada.' }
$conflictosMyCar=@(& git -C $Repositorio diff --name-only --diff-filter=U)
if($conflictosMyCar.Count -gt 0) { throw 'Resuelve primero los conflictos con el paquete de integración Elsa/RF50. No se reemplazó nada.' }
function HashNormalizadoMyCar([string]$rutaMyCar) {
    $textoMyCar=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($rutaMyCar)).Replace("`r`n","`n")
    $shaMyCar=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($shaMyCar.ComputeHash([Text.Encoding]::UTF8.GetBytes($textoMyCar)))).Replace('-','').ToLowerInvariant() }
    finally { $shaMyCar.Dispose() }
}
$raizMyCar=[IO.Path]::GetFullPath($Repositorio).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
foreach($fMyCar in $mMyCar.archivos) {
    $origenMyCar=Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta
    $destinoMyCar=[IO.Path]::GetFullPath((Join-Path $Repositorio $fMyCar.ruta))
    if(!$destinoMyCar.StartsWith($raizMyCar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Ruta fuera del repositorio.' }
    if(!(Test-Path -LiteralPath $origenMyCar -PathType Leaf) -or (Get-FileHash -LiteralPath $origenMyCar -Algorithm SHA256).Hash.ToLowerInvariant() -ne $fMyCar.sha256) { throw "Paquete incompleto o alterado: $($fMyCar.ruta)" }
    if($fMyCar.sha256Base) {
        if(!(Test-Path -LiteralPath $destinoMyCar -PathType Leaf) -or (HashNormalizadoMyCar $destinoMyCar) -ne $fMyCar.sha256Base) { throw "La base cambió en $($fMyCar.ruta). Comparte git status; no se reemplazó nada." }
    } elseif(Test-Path -LiteralPath $destinoMyCar) { throw "Ya existe $($fMyCar.ruta). No se reemplazó nada." }
}
$respaldoMyCar=Join-Path $env:USERPROFILE ('RespaldosMyCar/antes-permiso-red-local-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
foreach($fMyCar in $mMyCar.archivos) {
    $destinoMyCar=Join-Path $Repositorio $fMyCar.ruta
    if(Test-Path -LiteralPath $destinoMyCar) {
        $copiaMyCar=Join-Path $respaldoMyCar $fMyCar.ruta
        New-Item -ItemType Directory -Path (Split-Path -Parent $copiaMyCar) -Force | Out-Null
        Copy-Item -LiteralPath $destinoMyCar -Destination $copiaMyCar
    }
}
foreach($fMyCar in $mMyCar.archivos) {
    $destinoMyCar=Join-Path $Repositorio $fMyCar.ruta
    New-Item -ItemType Directory -Path (Split-Path -Parent $destinoMyCar) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'ARCHIVOS') $fMyCar.ruta) -Destination $destinoMyCar -Force
}
$rutasMyCar=@($mMyCar.archivos | ForEach-Object { $_.ruta })
& git -C $Repositorio add -- $rutasMyCar
if($LASTEXITCODE -ne 0) { throw 'No se pudieron preparar todos los archivos. Comparte git status.' }
& git -C $Repositorio diff --cached --check
if($LASTEXITCODE -ne 0) { throw 'Revisar diff --cached --check antes del commit.' }
Write-Host "Permiso de red local corregido. Respaldo: $respaldoMyCar"
Write-Host 'Recompila e instala la app. Sin commit, push, merge ni cambios de BD.'
& git -C $Repositorio status --short --branch
